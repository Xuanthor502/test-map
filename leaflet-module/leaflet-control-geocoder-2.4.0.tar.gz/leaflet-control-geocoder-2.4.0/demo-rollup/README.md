# leaflet-control-geocoder-demo-rollup

This demo demonstrates the usage of leaflet-control-geocoder using the [rollup.js](https://rollupjs.org/) bundler.

1. `cd demo-rollup/`
2. `npm install`
3. `npm run build`
4. `xdg-open index.html` or open `index.html` in your browser
